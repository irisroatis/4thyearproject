which_simulation = 2; % pick which .txt file with data to use
data= table2array(readtable('simulation_1d_binned'+string(which_simulation)+'.txt'));

% size of data
[N,M]=size(data);
number_param = 3;
N1 = N-1;

omega=0:2*pi/N:2*pi*(1-1/N); % discrete Fourier Frequencies
omega1=0:2*pi/N1:2*pi*(1-1/N1); % fourier Frequencies (differenced process)
filts=dpss(N,1)';
hh1=filts(1,:)'; % dpss taper of bandwith 1

% precomputation of h_t h_{t+\tau}
HHK=zeros(1,N); 
for mm=0:N-1
    HHK(mm+1)=sum(hh1(1:N-mm).*hh1(1+mm:N));
end

% needed for MCEM
N_monte_carlo = 20;
n_times = 20;
method = 'unif';
seed = 0;
bin_width = 1;
tol = 10^-3;

% to store parameters
par1 = zeros(number_param,M); % st whittle
par2 = zeros(number_param,M); % st whittle taper
par3 = zeros(number_param,M); % st whittle differencing
par4 = zeros(number_param,M); % st whittle aliasing
par5 = zeros(number_param,M); % st whittle aliasing tapering
par6 = zeros(number_param,M); % debiased whittle
par7 = zeros(number_param,M); % debiased whittle taper
par8 = zeros(number_param,M); % debiased whittle differencing
par9 = zeros(number_param,M); % mcem

times = zeros(9,M); % to store wall time
% options for minimization (used later)
options=optimset('GradObj','on','MaxFunEvals',1000,'MaxIter',1000);
LL=[0,0,0]; UU=10*ones(3,1); % Parameter bounds we search over

disp('Code progress:')

for j = 1:M % begin the loop over M
    disp(j/M)

    X = data(:,j);
    Y = diff(X); % and here is the differenced time series
    
    % centering
    X = X - mean(X);
    Y = Y - mean(Y);

    % periodograms
    Xh = X.*hh1; % tapered sequence
    JTh = fft(Xh);
    STh = (abs(JTh)).^2; % tapered data periodogram
    SX=(1/N)*(abs(fft(X))).^2; % standard periodogram
    SX1=(1/N1)*(abs(fft(Y))).^2; % periodogram differenced data

    % initial values for optimzation (random)
    xb = rand(3,1);
    xb(2) = xb(2)+1;

    % Standard Periodogram
    tic;
    par1(:,j)=fminsearchbnd(@(x) lwitt(x,SX.',N,omega,0,HHK, 0, 0),xb,LL,UU,options);
    times(1,j) = toc;
  

    % Standard Tapered
    tic;
    par2(:,j)=fminsearchbnd(@(x) lwitt(x,STh',N,omega,0,HHK, 0, 1),xb,LL,UU,options);
    times(2,j) = toc;
    

    % Standard Differenced Data
    tic;
    par3(:,j)=fminsearchbnd(@(x) lwittD(x,SX1',N1,omega1,0),xb,LL,UU,options);
    times(3,j) = toc;


    % Standard Periodogram Aliasing
    tic;
    par4(:,j)=fminsearchbnd(@(x) lwitt(x,SX.',N,omega,0,HHK, 1, 0),xb,LL,UU,options);
    times(4,j) = toc;

    % Standard Tapered Aliasing
    tic;
    par5(:,j)=fminsearchbnd(@(x) lwitt(x,STh',N,omega,0,HHK, 1, 1),xb,LL,UU,options);
    times(5,j) = toc;

    
    % De-biased Periodogram
    tic;
    par6(:,j)=fminsearchbnd(@(x) lwitt(x,SX',N,omega,1, HHK, 0, 0),xb,LL,UU,options);
    times(6,j) = toc;

    % De-biased Tapered 
    tic;
    par7(:,j)=fminsearchbnd(@(x) lwitt(x,STh',N,omega,1,HHK, 0, 1),xb,LL,UU,options);
    times(7,j) = toc;

    % De-biased Differenced Data
    tic;
    par8(:,j)=fminsearchbnd(@(x) lwittD(x,SX1',N1,omega,1),xb,LL,UU,options);
    times(8,j) = toc;

    % MCEM
    tic;
    [~, params, ~, ~, ~] = MCEM_univariate(data(:,j), N_monte_carlo, n_times, [xb(3),xb(1),xb(2)], method, seed, N, bin_width, tol);
    par9(1,j) =  params(end,2);
    par9(2,j) =  params(end,3);
    par9(3,j) =  params(end,1);
    times(9,j) = toc;
end


parameters = {par1, par2, par3, par4, par5, par6, par7, par8, par9};
bias = zeros(number_param,9);
variance = zeros(number_param,9);

for index = 1:9
    current = parameters{index};   
    
    % True parameters (uncomment based on .txt file used)

    % Simulation 1
%     param1 = 0.4; % alpha
%     param2 = 0.9; % beta
%     param3 = 0.5; % lambda
    
    % Simulation 2
    param1 = 0.8; % alpha
    param2 = 1.1; % beta
    param3 = 0.3; % lambda

    % compute bias
    bias(1,index) = (mean(current(1,:)) - param1);
    bias(2,index) = (mean(current(2,:)) - param2);
    bias(3,index) = (mean(current(3,:)) - param3);
    
    % compute sample variance
    variance(1,index) = var(current(1,:));
    variance(2,index) = var(current(2,:));
    variance(3,index) = var(current(3,:)); 
end

bias = round(bias,5);
bias = bias';
variance = round(variance,5);
variance = variance';
times_averaged = round(mean(times,2),5);

% comparison plots

group = [    ones(size(par1(1,:)'));
         2 * ones(size(par2(1,:)'));
         3 * ones(size(par3(1,:)'));
         4 * ones(size(par4(1,:)'));
         5 * ones(size(par5(1,:)'));
         6 * ones(size(par6(1,:)'));
         7 * ones(size(par7(1,:)'));
         8 * ones(size(par8(1,:)'));
         9 * ones(size(par9(1,:)'))];

f = figure;
f.Position = [100 100 700 200];
boxplot([par1(1,:)'; par2(1,:)'; par3(1,:)';par4(1,:)';par5(1,:)';par6(1,:)';par7(1,:)';par8(1,:)';par9(1,:)'],group)
set(gca,'XTickLabel',{'SW','STW','SFW','SAW','STAW','DW','DTW','DFW','MCEM'})
hold on
yline(param1,'Color','green','LineWidth',1)
title('Boxplot for Excitation Rate $\alpha$ Estimates','Interpreter','latex')
hold off

f = figure;
f.Position = [100 100 700 200];
boxplot([par1(2,:)'; par2(2,:)'; par3(2,:)';par4(2,:)';par5(2,:)';par6(2,:)';par7(2,:)';par8(2,:)';par9(2,:)'],group)
set(gca,'XTickLabel',{'SW','STW','SFW','SAW','STAW','DW','DTW','DFW','MCEM'})
hold on
set(gca, 'YScale', 'log')
yline(param2,'Color','green','LineWidth',1)
title('Boxplot for Decay Rate $\beta$ Estimates','Interpreter','latex')
hold off

f = figure;
f.Position = [100 100 700 200];
boxplot([par1(3,:)'; par2(3,:)'; par3(3,:)';par4(3,:)';par5(3,:)';par6(3,:)';par7(3,:)';par8(3,:)';par9(3,:)'],group)
set(gca,'XTickLabel',{'SW','STW','SFW','SAW','STAW','DW','DTW','DFW','MCEM'})
hold on
yline(param3,'Color','green','LineWidth',1)
title('Boxplot for Baseline $\lambda$ Estimates','Interpreter','latex')
hold off
