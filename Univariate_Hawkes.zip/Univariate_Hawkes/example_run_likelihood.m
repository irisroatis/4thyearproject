n_realisations = 100; % Set to whatever you like for you simulation study

v = 0.3;  % baseline parameter
beta= 1.1;  % decay parameter
alpha= 0.5;  % excitation parameter

param_esti_v = zeros(n_realisations,1);
param_esti_alpha = zeros(n_realisations,1);
param_esti_beta = zeros(n_realisations,1);


for explore_rep = 1:n_realisations
    disp(explore_rep/n_realisations)
    
    end_time = 1000;  % simulation time
 
    
    % p = 1 in the univariate case
    p = length(v);
  
    % sampling interval width
    bin_width = 1; 

    % simulate the Hawkes process 
    [t, ~, ~, ~] = SimulateMarkedHawkes1D(end_time, v, 0, beta, 'const', alpha);
    E = t{:};

    % aggregate the data
    data = transpose(histcounts(E, 0:bin_width:end_time));

    % get MLE of the simulated times
    options = optimoptions('fmincon','MaxIter',2e4,'MaxFunEvals',2e4,'Algo','interior-point','TolFun',1e-10,'TolX',1e-10,'GradObj','off','Hessian','off','Display','off','DerivativeCheck','off');
    myfunMv_true = @(z) complete_likelihood(E', z(1),z(2),z(3), end_time, p);
    [true_value_est,fval,exitflag,output,lambda,grad,hessian] = fmincon(myfunMv_true, [v,alpha,beta],[],[],[],[],[],[],[],options);
    
    % store MLE
    param_esti_v(explore_rep) = true_value_est(1);
    param_esti_alpha(explore_rep) = true_value_est(2);
    param_esti_beta(explore_rep) = true_value_est(3);

end

% figures

f = figure;
f.Position = [100 100 300 400];
hold on
boxplot(param_esti_v)
set(gca,'XTickLabel',{'MLE'})
yline(v,'-.g','LineWidth',1)
xlim([0.85 1.15])
ylim([min(param_esti_v)-0.05 max(param_esti_v)+0.05])
title('Estimate of the Background Intensity $\lambda$','FontSize', 14,'Interpreter','latex')
hold off

f = figure;
f.Position = [100 100 300 400];
hold on
boxplot(param_esti_alpha)
set(gca,'XTickLabel',{'MLE'})
yline(alpha,'-.g','LineWidth',1)
xlim([0.75 1.25])
ylim([min(param_esti_alpha)-0.05 max(param_esti_alpha)+0.05])
title('Estimate of the Jump Size $\alpha$','FontSize', 15,'Interpreter','latex')
hold off

f = figure;
f.Position = [100 100 300 400];
hold on
boxplot(param_esti_beta)
set(gca,'XTickLabel',{'MLE'})
yline(beta,'-.g','LineWidth',1)
xlim([0.75 1.25])
ylim([min(param_esti_beta)-0.05 max(param_esti_beta)+0.05])
title('Estimate of the Decay Rate $\beta$','FontSize', 15,'Interpreter','latex')
hold off


