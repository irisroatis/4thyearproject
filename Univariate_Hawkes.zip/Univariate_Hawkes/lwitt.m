function [out]=lwitt(x,SX,N,omega,Debias, HKK, aliasing, tapered)

% The function computes SW, STW, SAW, DW, DTW

if Debias == 0 % Standard Whittle
    omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi; % frequencies

    ESF3 = zeros(1,length(omega));
    if aliasing == 1
        k = -10:2:10;
    else
        k = 0;
    end

    for i = 1: length(omega)
         cal = x(3) / (1 - x(1)/x(2)) .* (sinc(0.5 * (omega(i)+k*pi) /pi).^2);
         cal = cal.* abs(1 - x(1) ./ (x(2)+1i*(omega(i)+k*pi))).^(-2);  
         ESF3(i) = sum(cal);
    end
    out=sum(log(ESF3))+sum(SX./ESF3); % summation

elseif Debias > 0 % De-biased Whittle

    omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi; % frequencies

    ESF3 = zeros(1,length(omega));
    k = -10:2:10;
    for i = 1: length(omega)
         cal = x(3) / (1 - x(1)/x(2)) .* (sinc(0.5 * (omega(i)+k*pi) /pi).^2);
         cal = cal.* abs(1 - x(1) ./ (x(2)+1i*(omega(i)+k*pi))).^(-2);  
         ESF3(i) = sum(cal);
    end
    acv = ifft(ESF3,'symmetric');
    if tapered == 0 
        ESF2=abs(real(2*fft(acv.*(1-(0:N-1)/N))-acv(1))); %blurred spectrum
        out=sum(log(ESF2))+sum(SX./ESF2); % summation
    else % tapered De-biased Whittle
        ESF2=abs(real(2*fft(acv.*HKK)-acv(1))); % blurred spectrum
        out=sum(log(ESF2))+sum(SX./ESF2); % summation
    end
end

