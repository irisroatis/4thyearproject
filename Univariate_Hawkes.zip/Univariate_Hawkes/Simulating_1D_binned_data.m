iterations = 200; % number of time series
end_time = 1000;  % simulation time

lambda_set = [0.5, 0.3];  % baseline parameter
alpha_set = [0.4, 0.8] ;  % excitation parameter
beta_set = [0.9, 1.1];  % decay parameter
bin_width = 1; 

% save simulated data
for simulation = 1: length(lambda_set)
    data_binned = zeros(end_time,iterations);
    lambda = lambda_set(simulation);
    beta = beta_set(simulation);
    alpha = alpha_set(simulation);
    parfor index = 1: iterations
        [t, ~, ~, ~] = SimulateMarkedHawkes1D(end_time, lambda, 0, beta, 'const', alpha);
        r = t{:};
        data_binned(:,index) = transpose(histcounts(r, 0:bin_width:end_time));
    end
    csvwrite('simulation_1d_binned'+string(simulation)+'.txt',data_binned)
    disp('Simulation '+string(simulation)+' out of '+string(length(lambda_set))+' done')
end

