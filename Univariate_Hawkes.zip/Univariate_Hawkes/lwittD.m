function [out]=lwittD(x,SX,N,omega, Debias)

% The function computes SFW, DFW, DFW

if Debias == 0 % Standard Whittle
   omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi;
   ESF3 = zeros(1,length(omega));
   k = 0;
   for i = 1: length(omega)
         cal = x(3) / (1 - x(1)/x(2)) .* (sinc(0.5 * (omega(i)+k*pi) /pi).^2);
         cal = cal.* abs(1 - x(1) ./ (x(2)+1i*(omega(i)+k*pi))).^(-2);  
         ESF3(i) = sum(cal);
    end
    ESF3 = (4*sin(omega/2).^2) .* ESF3;
    out=sum(log(ESF3(2:N)))+sum(SX(2:N)./ESF3(2:N)); % summation
else % De-biased Whittle
    N = N+1;
    omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi; % frequencies

    ESF3 = zeros(1,length(omega));
    k = -10:2:10;
    for i = 1: length(omega)
         cal = x(3) / (1 - x(1)/x(2)) .* (sinc(0.5 * (omega(i)+k*pi) /pi).^2);
         cal = cal.* abs(1 - x(1) ./ (x(2)+1i*(omega(i)+k*pi))).^(-2);  
         ESF3(i) = sum(cal);
    end
    acvA = ifft(ESF3,'symmetric');
    
    N = N-1;
    acv=zeros(1,N); 
    acv(1)=2*acvA(1)-2*acvA(2);
    for ii = 2:N % autocovariance of differenced process
        acv(ii)=2*acvA(ii)-acvA(ii-1)-acvA(ii+1);
    end
    ESF2=abs(real(2*fft(acv.*(1-(0:N-1)/N))-acv(1))); % blurred spectrum
    out=sum(log(ESF2(2:N)))+sum(SX(2:N)./ESF2(2:N)); % summation
end