iterations = 1000;
end_time = 2000;  % simulation time
data = zeros(end_time,iterations);
v = 0.3;  % baseline parameter
alpha= 0.5 ;  % excitation parameter
beta= 1.1;  % decay parameter
bin_width = 1; 
SX = zeros(N,iterations);
N = end_time;

for index = 1: iterations
  disp(index/iterations)
  % simulate times
  [t, ~, ~, ~] = SimulateMarkedHawkes1D(end_time, v, 0, beta, 'const', alpha);
  r = t{:};

  % aggregate data
  X = transpose(histcounts(r, 0:bin_width:end_time));

  % substract mean
  X = X - mean(X);

  % compute periodogram
  SX(:,index)=(1/N)*(abs(fft(X))).^2; 
end


x = [alpha, beta, v]; % true parameters
omega=0:2*pi/N:2*pi*(1-1/N); % discrete Fourier Frequencies
omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi; % shifted frequencies

% compute discrete-time spectra
ESF3 = zeros(1,length(omega));
k = -10:2:10;
for i = 1: length(omega)
    cal = x(3) / (1 - x(1)/x(2)) .* (sinc(0.5 * (omega(i)+k*pi) /pi).^2);
    cal = cal.* abs(1 - x(1) ./ (x(2)+1i*(omega(i)+k*pi))).^(-2);  
    ESF3(i) = sum(cal);
end


% compute cont-time spectra
cal = x(3) / (1 - x(1)/x(2)) .* (sinc(0.5 * omega /pi).^2);
cal = cal.* abs(1 - x(1) ./ (x(2)+1i*omega)).^(-2);  

% comparison_plot
figure
hold on
plot(mean(SX,2),DisplayName='Average Periodogram',LineWidth=0.75)
plot(ESF3,DisplayName='Discrete-Time Spectra',LineWidth=1)
plot(cal,DisplayName='Continuous-Time Spectra',LineWidth=1)
title({'Theoretical Spectra vs Periodogram for a Binned Hawkes Process','$\alpha = 0.5$, $\beta = 1.1$, $\lambda = 0.3$'},'interpreter','latex','FontSize',15)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
