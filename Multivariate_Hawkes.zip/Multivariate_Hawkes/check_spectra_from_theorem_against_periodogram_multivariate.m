D = 2;

% background intensity [Dx1]
values_lambda       = [0.7, 0.5]';  

% intensity from edge effect [DxD]
Y0       = 0 * ones(D);

% rate of decay [DxD]
values_beta    =  [1.5 2.0; 2.0 3.5]; % SINCE BETA AT DENOMINATOR WE CANNOT TAKE beta = 0

% jump amplitude
values_alpha = [ 0.7 0.6; 0.6 1.0];

n = 2000;
omega=0:2*pi/n:2*pi*(1-1/n); % Discrete Fourier Frequencies
omega(n-floor(n/2)+1:n)=omega(n-floor(n/2)+1:n)-2*pi; % frequencies


bin_width = 1;

how_many = 1000;

s_11 = zeros(length(omega),1);
s_21 = zeros(length(omega),1);
s_12 = zeros(length(omega),1);
s_22 = zeros(length(omega),1);

for i = 1: how_many
    disp(i/how_many)
    
    result_periodogram = zeros(D,D);


    [t, ~, ~, ~] = SimulateMarkedHawkesMD(n, values_lambda, Y0, values_beta, 'const', values_alpha);
    times1 = t{1};
    times2 = t{2};
%     times3 = t{3};
    times1 = transpose(histcounts(times1, 0:bin_width:n));
    times2 = transpose(histcounts(times2, 0:bin_width:n));
%     times3 = transpose(histcounts(times3, 0:bin_width:n));
    
    
    %center the two
    times1 = times1 - mean(times1);
    times2 = times2 - mean(times2);     
%     times3 = times3 - mean(times3);     

    both_processes = cat(2,times1, times2);
    periodogram = fft(both_processes); % Regular

    for range_omega = 1: length(omega)
%       disp(i/how_many)
        % Simulate Hawkes
        
        period_at_omega_chosen = periodogram(range_omega,1:end);
        peri = (1/n) * (period_at_omega_chosen') * period_at_omega_chosen; 
        
        s_11(range_omega) = s_11(range_omega) + peri(1,1);
        s_12(range_omega) = s_12(range_omega) + peri(1,2);
        s_21(range_omega) = s_21(range_omega) + peri(2,1);
        s_22(range_omega) = s_22(range_omega) + peri(2,2);
    
    end
end

s_11 = s_11/how_many;
s_12 = s_12/how_many;
s_22 = s_22/how_many;
s_21 = s_21/how_many;

s_11_actual = zeros(length(omega),1);
s_21_actual = zeros(length(omega),1);
s_12_actual = zeros(length(omega),1);
s_22_actual = zeros(length(omega),1);

k_to_try = [-2,-1,0,1,2];


for range_omega = 1: length(omega)
    omega_chosen = omega(range_omega);
    s = zeros(D,D);
    for k= -5: 5
        s = s+ mutuallyexcitingspectra(values_alpha, values_beta, values_lambda, omega_chosen, k);
    end
%     s = transpose(mutuallyexcitingspectra(values_alpha, values_beta, values_lambda, omega_chosen));
    s_11_actual(range_omega) = s(1,1);
    s_12_actual(range_omega) = s(1,2);
    s_21_actual(range_omega) = s(2,1);
    s_22_actual(range_omega) = s(2,2);
end

fontSize = 15; 

figure
hold on
plot(real(s_11),DisplayName='Average Periodogram',LineWidth=0.75)
plot(real(s_11_actual),DisplayName='Discrete-Time Spectra',LineWidth=1)
title('Real Part of $S_{11}$', 'Interpreter','latex','FontSize', fontSize)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
saveas(gcf,'real11.png')

figure
hold on
plot(imag(s_11),DisplayName='Average Periodogram',LineWidth=0.75)
plot(imag(s_11_actual),DisplayName='Discrete-Time Spectra',LineWidth=1)
title('Imaginary Part of $S_{11}$', 'Interpreter','latex','FontSize', fontSize)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
saveas(gcf,'imag11.png')

figure
hold on
plot(real(s_12),DisplayName='Average Periodogram',LineWidth=0.75)
plot(real(s_12_actual),DisplayName='Discrete-Time Spectra',LineWidth=1)
title('Real Part of $S_{12}$', 'Interpreter','latex','FontSize', fontSize)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
saveas(gcf,'real12.png')

figure
hold on
plot(imag(s_12),DisplayName='Average Periodogram',LineWidth=0.75)
plot(imag(s_12_actual),DisplayName='Discrete-Time Spectra',LineWidth=1)
title('Imaginary Part of $S_{12}$', 'Interpreter','latex','FontSize', fontSize)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
saveas(gcf,'imag12.png')

figure
hold on
plot(real(s_21),DisplayName='Average Periodogram',LineWidth=0.75)
plot(real(s_21_actual),DisplayName='Discrete-Time Spectra',LineWidth=1)
title('Real Part of $S_{21}$', 'Interpreter','latex','FontSize', fontSize)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
saveas(gcf,'real21.png')

figure
hold on
plot(imag(s_21),DisplayName='Average Periodogram',LineWidth=0.75)
plot(imag(s_21_actual),DisplayName='Discrete-Time Spectra',LineWidth=1)
title('Imaginary Part of $S_{21}$', 'Interpreter','latex','FontSize', fontSize)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
saveas(gcf,'imag21.png')


figure
hold on
plot(real(s_22),DisplayName='Average Periodogram',LineWidth=0.75)
plot(real(s_22_actual),DisplayName='Discrete-Time Spectra',LineWidth=1)
title('Real Part of $S_{22}$', 'Interpreter','latex','FontSize', fontSize)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
saveas(gcf,'real22.png')

figure
hold on
plot(imag(s_22),DisplayName='Average Periodogram',LineWidth=0.75)
plot(imag(s_22_actual),DisplayName='Discrete-Time Spectra',LineWidth=1)
title('Imaginary Part of $S_{22}$', 'Interpreter','latex','FontSize', fontSize)
xlabel('$\omega_i$',Interpreter='latex',FontSize=fontSize)
legend(Location='north',FontSize=11)
hold off
saveas(gcf,'imag22.png')


% function [out_inside] = mutuallyexcitingspectra(values_alpha, values_beta, values_lambda, omega_chosen)
% K = size(values_beta);
% K = K(1);
% 
% identity = eye(K);
% 
% middle = identity - values_alpha ./ values_beta;%calc_mu(values_alpha, values_beta, K, 0);
% diagonal_matrix = diag ((middle \identity) * values_lambda);
% 
% out_inside = size(K, K);
% 
% for k = -1:1
%     needed_plus = 2*k*pi + omega_chosen;
%     lastone = identity - values_alpha ./ (1j * needed_plus + values_beta); %calc_mu(values_alpha, values_beta, K, needed_plus);
%     inverse_lastone = (lastone \ identity);
%     out_inside = out_inside + (sinc(0.5 * needed_plus/pi))^2 * inverse_lastone' * diagonal_matrix * inverse_lastone;
% end
% 
% end

function [out] = mutuallyexcitingspectra(values_alpha, values_beta, values_lambda, omega_chosen, k, delta)
K = size(values_beta);
K = K(1);
needed_plus = 2*k*pi + omega_chosen;
lastone = eye(K) - calc_mu(values_alpha, values_beta, K, needed_plus);
middle = eye(K) -  calc_mu(values_alpha, values_beta, K, 0);


out = (sinc(0.5 * needed_plus/pi))^2 * inv(lastone)' * diag (inv(middle)*values_lambda) * inv(lastone);

    function [matrix] = calc_mu(values_alpha, values_beta, K, needed)
        matrix = zeros(K,K);
      
        for i = 1:K
            for j = 1:K
                matrix(i,j) = values_alpha(i,j) / (1j * needed + values_beta(i,j));
            end
        end
    end
end



