% dimension of Hawkes considered
D = 2;

Y0 = 0 * ones(D); % needed for simulation

% ground truth parameters
v = [0.7, 0.5]';  % lambda
% SINCE BETA AT DENOMINATOR WE CANNOT TAKE beta = 0
B =  [1.5 2.0; 2.0 3.5];  % beta
A =   [ 0.7 0.6; 0.6 1.0]; % alpha

true_param = [0.7 ,0.6, 0.6, 1.0, 1.5,2, 2, 3.5, 0.7, 0.5]'; % col vector of true parameters

N = 1000; % end time
end_time = N; 
M = 20; % number of time series to simulate

% sampling interval
bin_width = 1;
delta = bin_width;

% needed for Whittle
omega=0:2*pi/N:2*pi*(1-1/N); % discrete Fourier frequencies
omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi; % shift frequencies


%needed for MCEM
N_monte_carlo = 10;
n_times = 5;
n_splits = 5;

% options for minimization (used later)
options=optimset('GradObj','on','MaxFunEvals',100,'MaxIter',100,'Display','off');
LL=0*ones(2*D^2+D,1) ; UU=10*ones(2*D^2+D,1); % parameter bounds we search over

parameters = zeros(M, 2*D^2+D); % to store parameters of whittle
final_mcem_parameters = zeros(M, 2*D^2+D); % to store parameters of MCEM


for iterations = 1: M
    disp('Code progress:')
    disp(iterations/M)

    xb = [0.6, 0.5, 0.7, 0.9,1.4, 1.9, 2.1, 3.4,0.6, 0.4 ]; % initialisation

    % simulating time series 
    [E_test,Y_test,~,~] = SimulateMarkedHawkesMD(end_time, v, zeros(2,1), B, 'const', A);
    E_test1 = cell2mat(E_test(1));
    E_test2 = cell2mat(E_test(2));
    bins = 0:bin_width:end_time;

    % aggregating the data
    bin_sim1 = transpose(histcounts(E_test1, bins));
    bin_sim2 = transpose(histcounts(E_test2, bins)); 
    data = [bin_sim1, bin_sim2];
    
    % substracting the mean for whittle estimation
    times1 = bin_sim1 - mean(bin_sim1);
    times2 = bin_sim2 - mean(bin_sim2);   
    both_processes = cat(2,times1, times2);
    periodogram = fft(both_processes); % computing J as denoted in report
    
    % multivariate standard Whittle with aliasing (MSAW)
    disp('Start Whittle')
    parameters(iterations,1:end) = fminsearchbnd(@(x) lwitt_multidimensional(x,periodogram ,N,omega, D),xb,LL,UU,options);
    disp('End Whittle')
    
    % multivariate MCEM unif
    disp('Start MCEM')
    [params_uniform, ~, ~, ~, ~, ~] = MCEM_algorithm_full(data, 0, N_monte_carlo, n_times, 0, end_time, bin_width, n_splits, 'uniform'); 
    disp('End Whittle')
    mcem_parameters = [sum(params_uniform(3:2:end,:),1);sum(params_uniform(4:2:end,:),1)]/(n_times-1);
    % changing order of parameters
    final_mcem_parameters(iterations,1:end) = [mcem_parameters(1,2),mcem_parameters(1,3),mcem_parameters(2,2),mcem_parameters(2,3),...
        mcem_parameters(1,4),mcem_parameters(1,5),mcem_parameters(2,4),mcem_parameters(2,5),mcem_parameters(1,1),mcem_parameters(2,1)];

end

% saving parameters in files
csvwrite('my_parameters.mat',parameters)
csvwrite('mcem_parameters.mat',final_mcem_parameters)


% create boxplots to visualise the estimates
group = [    ones(size(parameters(:,1)));
         2 * ones(size(final_mcem_parameters(:,1)))];

f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,1); final_mcem_parameters(:,1)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(A(1,1),'Color','green','LineWidth',1)
ylabel('Estimates of $\alpha_{11}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'a11.png')

f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,2); final_mcem_parameters(:,2)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(A(1,2),'Color','green','LineWidth',1)
ylabel('Estimates of $\alpha_{12}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'a12.png')

f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,3); final_mcem_parameters(:,3)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(A(2,1),'Color','green','LineWidth',1)
ylabel('Estimates of $\alpha_{21}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'a21.png')


f = figure;
f.Position = [100 100 700 200];
hold on
yline(A(2,2),'Color','green','LineWidth',1)
hold on
boxplot([parameters(:,4); final_mcem_parameters(:,4)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
ylabel('Estimates of $\alpha_{22}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'a22.png')

f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,5); final_mcem_parameters(:,5)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(B(1,1),'Color','green','LineWidth',1)
ylabel('Estimates of $\beta{11}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'b11.png')

f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,6); final_mcem_parameters(:,6)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(B(1,2),'Color','green','LineWidth',1)
ylabel('Estimates of $\beta_{12}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'b12.png')

f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,7); final_mcem_parameters(:,7)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(B(2,1),'Color','green','LineWidth',1)
ylabel('Estimates of $\beta_{21}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'b21.png')

f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,8); final_mcem_parameters(:,8)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(B(2,2),'Color','green','LineWidth',1)
ylabel('Estimates of $\beta_{22}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'b22.png')

f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,9); final_mcem_parameters(:,9)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(v(1,1),'Color','green','LineWidth',1)
ylabel('Estimates of $\lambda_{1}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'l1.png')


f = figure;
f.Position = [100 100 700 200];
boxplot([parameters(:,10); final_mcem_parameters(:,10)],group)
set(gca,'XTickLabel',{'MSAW','MCEM Unif'},'FontSize',15)
hold on
yline(v(2,1),'Color','green','LineWidth',1)
ylabel('Estimates of $\lambda_{2}$','Interpreter','latex','FontSize',18)
hold off
saveas(gcf,'l2.png')

% create summary statistics
% calculate mean (after removing outliers)
avg_my_param = mean(rmoutliers(parameters),1);
avg_mcem_param =mean(rmoutliers(final_mcem_parameters),1);

% calculate st deviation of mean
st = zeros(2, 10);
for i = 1:10
    st(1,i) = std(rmoutliers(parameters(:,i)-avg_my_param(i)));
    st(2,i) = std(rmoutliers(final_mcem_parameters(:,i)-avg_mcem_param(i)));
end
st =round(st, 3);

whittle_st = st(1,:)';
mcem_st = st(2,:)';
avg_my_param = round(avg_my_param,3);
avg_mcem_param = round(avg_mcem_param,3);



function [out]=lwitt_multidimensional(x,periodogram, N, omega, D)
% This function computes the standard Whittle likelihood with aliasing 

ESF3 = zeros(1,N);

% put parameters into matrices for easier handling
values_alpha = reshape(x(1:D^2),D,D)';
values_beta = reshape(x(D^2+1:2 * D^2),D,D)';
values_lambda = reshape(x(2 * D^2+1: end),1,D)';
     
for i = 1: N
    period_at_omega_chosen = periodogram(i,1:end); % select J at current omega
    % comoute periodogram I at current omega
    In_omega = (1/N) * (period_at_omega_chosen') * period_at_omega_chosen; 
    omega_chosen = omega(i);
    f = zeros(D,D); % to store aliased spectrum
    % add together contributions of the continuous-time spectra
    for k = -5: 5
    f = f+ mutuallyexcitingspectra(values_alpha, values_beta, values_lambda, omega_chosen, k); 
    end
    % compute Whittle likelihood
    ESF3(i) = log(det(f)) + trace(In_omega * inv(f));
end

% we leave out some frequencies as mentioned in report
out = sum(ESF3(50:end-50));


function [out] = mutuallyexcitingspectra(values_alpha, values_beta, values_lambda, omega_chosen, k)
% This function computes the continuous-time spectra (with possibility of
% adding 2 pi k at omega)
K = size(values_beta);
K = K(1);
needed_plus = 2*k*pi + omega_chosen;
lastone = eye(K) - calc_mu(values_alpha, values_beta, K, needed_plus);
middle = eye(K) - calc_mu(values_alpha, values_beta, K, 0);

% using theorem from report compute discrete time spectra
out = (sinc(0.5 * needed_plus/pi))^2 * inv(lastone)' * diag (inv(middle)*values_lambda) * inv(lastone);

    function [matrix] = calc_mu(values_alpha, values_beta, K, needed)
        % This function computes the tilde mu from the report
        matrix = zeros(K,K);
        for index = 1:K
            for j = 1:K
                matrix(index,j) = values_alpha(index,j) / (1j * needed + values_beta(index,j));
            end
        end
    end
end



end

