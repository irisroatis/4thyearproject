function[l] = inthawkesm(m,t,H,par) 
% INTHAWKESM  Point-in-time intensity of a Hawkes process
%             (Constant-unconditional-intensity first-order exponential-
%             decay M-variate  Hawkes process; single component series)
% Inputs      m   - index of constituent series 
%             t   - time when intensity is to be evaluated, n*1  vector
%             H   - process history, M*1 cell array; vector H{n} stores 
%                   event-occurrence times for component series n. Zero
%                   starting time assumed.
%             par - process-parameters structure containing fields
%                   'mu'    - M*1 vector (unconditional intensities)
%                   'alpha' - M*M matrix (multiply the exponent terms)
%                   'beta'  - M*M matrix (degrees of the exponents)
% Outputs     l   - intensity of the component series m at time t given
%                   process history H, n*1 vector
% Example     See HAWKESDEMO
% Author      Dimitri Shvorob, dimitri.shvorob@vanderbilt.edu, 12/12/07
k = length(H);
n = length(t);
l = par.mu(m)*ones(n,1);
for i = 1:n
    for j = 1:k
        h = H{j};
        h = h(h < t(i));
        if ~isempty(h)
           d = t(i) - h;
           l(i) = l(i) + par.alpha(m,j)*sum(exp(-par.beta(m,j)*d));
        end   
    end
end    