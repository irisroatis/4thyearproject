%% HAWKESDEMO: Simulate and visualize a Hawkes process 
% (one of constant-unconditional-intensity, first-order, exponential-decay type)
%



%% Univariate process 2
% Self-exciting: alpha > 0
par2.mu    = 0.3;
par2.alpha = 0.5;
par2.beta  = 0.9;

%% Simulated histories of univariate processes 
t = 25;
%%

h2 = simhawkes1(t,par2);

%% Intensity-and-event-occurrence plots

showhawkesm(1,t,h2,par2)


