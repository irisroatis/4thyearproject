function showhawkesm(m,t,H,par)
% SHOWHAWKESM Plot intensities and event times of a Hawkes process
%             (Constant-unconditional-intensity first-order exponential-
%             decay M-variate Hawkes process; selected component series)
% Inputs      m   - indexes of selected component series, k*1 vector
%             t   - end time (Zero starting time assumed)
%             H   - process history, M*1 cell array; vector H{n} stores 
%                   event-occurrence times for component series n
%             par - process-parameters structure containing fields
%                   'mu'    - M*1 vector (unconditional intensities)
%                   'alpha' - M*M matrix (multiply the exponent terms)
%                   'beta'  - M*M matrix (degrees of the exponents)
% Example     See HAWKESDEMO
% Author      Dimitri Shvorob, dimitri.shvorob@vanderbilt.edu, 12/12/07
x = linspace(0,t,100);
k = length(m);
figure, set(gcf,'Color','w')
for i = 1:k
    n = m(i);
    h = H{n}; 
    l = inthawkesm(n,x,H,par);
    y = 0.05*max(l);
    e = length(h);
    hold on
    plot(h,zeros(length(h),1),'x','LineWidth', 1,'MarkerSize',7,'Color','k');

%     for j = 1:e
%         line([h(j) h(j)],[0 y],'Color','k','LineWidth',2), hold on
%     end    
    h
    plot(x,l,'Color','k','LineWidth',2)
    axis([0 t 0 1.1*max(l)])
    title (['Conditional Intensity Self-Exciting Hawkes Process'])
    ylabel(['Conditional Intensity, \it\lambda^{*}'])
    xlabel(['Event-occurrence time (' num2str(e) ' events total)'])

h = sort(h);
hold off
figure
set(gcf,'Color','w')

 x1 = 0:0.01:h(1);
 x2 = 0 * ones(length(x1),1);
 plot(x1,x2,'Color','k','LineWidth',2);
 line([h(1) h(1)],[0 1],'LineStyle',':','Color','k','LineWidth',2), hold on
 plot(h(1),0,'ko')
for i = 1:length(h)-1
    x1 = h(i):0.01:h(i+1);
    x2 = i * ones(length(x1),1);
    hold on
    plot(x1,x2,'Color','k','LineWidth',2); 
    plot(h(i),i,'ko','MarkerFaceColor','k')
    plot(h(i+1),i,'ko')
    line([h(i+1) h(i+1)],[i i+1],'LineStyle',':','Color','k','LineWidth',2), hold on
end
x1 = h(end):0.01:25;
x2 = (i+1) * ones(length(x1),1);
hold on
plot(h(end),i+1,'ko','MarkerFaceColor','k')
plot(x1,x2,'Color','k','LineWidth',2);
plot(h,zeros(length(h),1),'x','LineWidth', 1,'MarkerSize',7,'Color','k')
title(['Counting Process'])
ylabel(['\itN(t)'])
xlabel(['Event-occurrence time (' num2str(e) ' events total)'])


hold off

end